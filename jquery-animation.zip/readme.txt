Requires any text editor and browser.
Visual Studio Express 2012 is used for demos, but any HTML editor is fine.
Internet access to acquire jQuery and other libraries required.