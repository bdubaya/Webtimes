﻿
// BuyNowButton.js

(function (ns) {

    ns.BuyNowButton = function (id) {



    }
}(window.PS = window.PS || {}));


